# yolo
YOLO v3 Object Detection with Voice Feedback using gTTS

Download the yolov3 weights from
https://pjreddie.com/media/files/yolov3.weights
